<img style="float:left" height="64px"   src="/imaxes/logo.png" alt="" />

# Bootstrap
Aprendendo a traballar con GitHub, markdown e  co framework Bootstrap.

- [x] Fai un fork deste repositorio
- [x] Modifica o teu _README.md_ poñendo o teu logo, unha presentación do proxecto e vai marcando estas tarefas que vas facendo
- [x] Descarga o repositorio -se xa es maior podes clonalo, facer control de versións..._puuufff_-
- [ ] Modifica todo: texto, imaxes, todos os `<div> ` que atopes copia aquí e alá.
- [ ] No wiki copia e pega anacos de código `<div>` e explica para que valen: Fai unha páxina por `class`. O que vén sendo: fai a chuleta sen que ninguén se entere. A túa primeira páxina do wiki: `jumbotron`
- [ ] Actualiza o teu repositorio subindo a carpeta do teu traballo *cando remates.*
- [ ] Enlaza no teu sitio web xxxxx.github.io para poder ver que quedou estupendo. 


	Consulta todo esto:

	* [O noso vello libro de texto](https://www.w3schools.com/bootstrap4/default.asp)

	* [Os culpables de todo](https://getbootstrap.com/docs/4.0/getting-started/introduction/)

	* [O novo material que imos usar](https://www.quackit.com/bootstrap/bootstrap_4/tutorial/)


	```
	Lembrade mirar o código de todo. Incluso dese .md
	```

	Irei facendo un wiki pero vai ser convosco
